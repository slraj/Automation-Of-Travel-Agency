<?php
if(isset($_POST['vid'])){
	
	$vid = $_POST['vid'];
	$source = $_POST['source'];
	$destination = $_POST['destination'];
	include ('connection2.php');
	$qry = mysqli_query($connect,"SELECT * FROM route WHERE source = '$source' AND destination = '$destination'");
	if(mysqli_num_rows($qry)==0){
		die("something went wrong please try after sometime");
	}
	$routeInfo = mysqli_fetch_array($qry);
	$km = $routeInfo['distance'];
	
	
	$qry = mysqli_query($connect,"SELECT * FROM vehicle WHERE v_id = '$vid'");
	if(mysqli_num_rows($qry)==0){
		die("something went wrong please try after sometime(vehicle)");
	}
	$vehicleInfo = mysqli_fetch_array($qry);
	$ppk = $vehicleInfo['fareperkm'];
	#amount
	$total = 0;
	$total = $ppk * $km;
	
	# gst 
	$gst = 0;
	$gst = 5/100 * $total;
	
	$total += $gst;
	
	echo round($total,0);
	
	
}






?>