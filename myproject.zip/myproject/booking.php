<!doctype html>
<html>
<head>
		<title>C.R.S.|Book Here|DO Not Reload The Page</title>
        <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript">
function valid()
{
if(document.booking.source.value=="")
{
alert("Source Filed is Empty !!");
document.booking.source.focus();
return false;
}
else if(document.booking.destination.value=="")
{
alert("Destination Filed is Empty !!");
document.booking.destination.focus();
return false;
}
else if(document.booking.name.value=="")
{
alert("Car Name Filed is Empty !!");
document.booking.name.focus();
return false;
}
else if(document.booking.cardno.value=="")
{
alert("Card Number Filed is Empty !!");
document.booking.cardno.focus();
return false;
}
else if(document.booking.expdate.value=="")
{
alert("Expiry Date Filed is Empty !!");
document.booking.expdate.focus();
return false;
}
else if(document.booking.cvv.value=="")
{
alert("CVV Filed is Empty !!");
document.booking.cvv.focus();
return false;
}
else if(document.booking.chname.value=="")
{
alert("Card Holder Name Filed is Empty !!");
document.booking.chname.focus();
return false;
}
return true;
}
</script>

</head>
<body>
		<!-- Nav -->
		<?php include ("navbar.php")?>
		<!-- Header -->
			<header id="header">
				<div class="logo"><a href="index.php">Car Rental Service <span>by C.R.S.</span></a></div>
                 <a href="#menu"><span>Menu</span></a>
			</header>
    

			<section id="banner" class="bg-img" data-bg="abc.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h3><p align="center">!!!Journey Detail!!!</p></h3>
						</header>
						<div class="content">
                        	<div style="width: 50%; float:left">
     							<form name="booking" action="cnfrm.php" method="post" onSubmit="return valid();">
                                	<table align="center">
    									<tr>
                                        	<?php $getsource = mysqli_query($connect,"SELECT DISTINCT source FROM route");
											if(mysqli_num_rows($getsource)==0){
												echo 'No source found';
											}else{?>
        									<td>From</td>
           									<td align="center"><select name="source" id="source">
                                            <option value="">SELECT SOURCE</option>
                                            <?php while($each = mysqli_fetch_array($getsource)){?>
                                            	<option style="background-color:#000"><?php echo $each['source']?></option>
                                            <?php } ?></select></td>
        								</tr>
        							</table>
                               
  							</div>
							<div style="width: 50%; float:right">
     							
                                <table align="center">
                                <tr>
        							<?php $getdestination = mysqli_query($connect,"SELECT DISTINCT destination FROM route");
											if(mysqli_num_rows($getsource)==0){
												echo 'No destination found';
											}else{?>
        									<td>To</td>
           									<td align="center"><select name="destination" id="destination">
                                            <option value="">SELECT DESTINATION</option>
                                            <?php while($each1 = mysqli_fetch_array($getdestination)){?>
                                            	<option style="background-color:#000"><?php echo $each1['destination']?></option>
                                            <?php } ?></select></td>
        						</tr>
                                </table>
        					</div>
						</div><hr>
                        <header>
							<h3><p align="center">!!!SELECT THE CAR!!!</p></h3>
						</header>
						<div class="content">
                        	<div align="center">
                                	<table align="center">
    									<tr>
                                        	<?php $getvehicle = mysqli_query($connect,"SELECT * FROM vehicle");
											if(mysqli_num_rows($getvehicle)==0)
											{
												echo 'No source found';
											}
											else
											{?>
        									<td>Car</td>
           									<td align="center"><select name="v_id" id="v_id">
                                            <option value="">SELECT VEHICLE</option>
                                            <?php while($each2 = mysqli_fetch_array($getvehicle)){?>
                                            	<option style="background-color:#000" value="<?php echo $each2['v_id']?>"><?php echo $each2['name']?></option>
                                            <?php } ?></select></td>
        								</tr>
        							</table>	
        					</div>
						</div>
					</article>
				</div>
			</section>
            <section id="post" class="wrapper bg-img" data-bg="banner3.jpg">
				<div class="inner">
					<article class="box">
						<h2><p align="left"><font face="algerian" color="#FFFFFF"><img src="paylogo.jpg"><u>Pay Here</u></font></p></h2>
							<table align="center" border="2" cellpadding="10" cellspacing="5">
                            <tr>
							<td>Payment Amount</td>
                            
							<td><input type="text" id="amount" name="amount" required readonly></td>
							</tr>
							<tr>
							<td>Card Number</td>
                            
							<td><input type="text" id="cardno" name="cardno" placeholder="Enter your card number" required></td>
							</tr>
							<tr>
							<td>Expiry Date</td>
							<td><input type="date" id="expdate" name="expdate" required></td>
							</tr>
							<tr>
							<td>CVV Number</td>
							<td><input type="password" id="cvv" name="cvv" placeholder="Enter your CVV Number" required></td>
							</tr>
							<tr>
							<td>Card Holder Name</td>
							<td><input type="text" id="chname" name="chname" placeholder="Enter Card Holder Name" required></td>
							</tr>
                            <tr>
                            	<td><a href="cnfrm.php"><input type="submit" name="submit" value="PAY NOW"></a></td>
                            </tr>
							</table>
						</form>
					</article>
				</div>
			</section>
	    <!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
<?php
}
}
}
?>
<script>
$(document).ready(function(e) {
    
	$("#v_id").change(function(){
		var vid = $(this).val();
		var source = $("#source").val();
		var destination = $("#destination").val();
		
		$.ajax({
			url:"getFare.php",
			type:"POST",
			data:{vid:vid,source:source,destination:destination},
			success: function(response){
				if(response){
					$("#amount").val(response);
				}
			}
			
		});
		
	})
	
});
</script>
</body>
</html>