<?php include('connection2.php');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Vehicle</title>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
</head>

<body>
<div>
<h1 align="center" style="color:#4CAF50">Vehicle Details</h1>
  <form method="post" enctype="multipart/form-data">
    <label for="name"> Name</label>
    <input type="text" id="fname" name="name" placeholder="Vehicle name..">

    <label for="type">Type</label>
    <input type="text" id="lname" name="type" placeholder="Vehicle type..">
    
    <label for="regnum"> Registration Number</label>
    <input type="text" id="fname" name="regnum" placeholder="Vehicle registration number..">

     <label for="seatcap"> Seat Capacity</label>
    <input type="text" id="fname" name="seatcap" placeholder="Seat Capacity..">
    
    <label for="fareperkm">Rate per KM</label>
    <input type="text" id="fname" name="fareperkm" placeholder="Fare per KM..">
    
     <label for="car">Car</label>
    <input type="file" id="fname" name="file"><br>
    
    <label for=""></label>
    
    <?php $getDriver = mysqli_query($connect,"SELECT * FROM driver WHERE status = 0");
	if(mysqli_num_rows($getDriver)==0){
		echo 'No drivers found';
	}else{?>
     <label for="driver">Driver</label>
    <select name="driver">
    <?php while($each = mysqli_fetch_array($getDriver)){?>
    <option value="<?php echo $each['d_id']?>"><?php echo $each['name']?></option>
    <?php } ?>
    </select>
<?php } ?>





   
    <input type="submit" value="Submit" name="submit">
  </form>
  <a href="dashboard.php"><img src="back.png"></a>
</div>

<?php
	if(isset($_POST['submit'])){
		$name=$_POST['name'];
		$type=$_POST['type'];
		$regnum=$_POST['regnum'];
		$seatcap=$_POST['seatcap'];
		$fareperkm=$_POST['fareperkm'];
		$driver=$_POST['driver'];
		$updateDriverStatus = mysqli_query($connect,"UPDATE driver SET status = 1 WHERE d_id = '$driver'");
		$file_name=$_FILES['file']['name'];
	    $file_type=$_FILES['file']['type'];
	     $file_size=$_FILES['file']['size'];
	#check if file size exceeds approax  2 MB
	
	if($file_size > 2000000){
		echo "<h3 style='color:red'>File size exceeding...! Please upload a file less than 2 MB</h3>";
	}else{
		#file size is ok
		#now check file type
		if($file_type=="image/png" or $file_type=="image/jpg" or $file_type=="image/PNG" or $file_type=="image/JPG" or $file_type=="image/jpeg" or  $file_type=="image/JPEG" or $file_type=="image/gif"){
			#file is ok
			# now create the destination folder /dir
			$dir="images";
			if(!file_exists($dir)){
				#if dir with name 'images' does not exists then create a new folder using mkdir function
				mkdir($dir);
			}
			#custom creation of dest folder where the file will get saved under c:/wamp/wwww/fileuploading/images/....
			$destination_path=$dir.'/'.rand(0000,9999).'_'.$file_name;
			#upload the file from source to destination 
			$upload = move_uploaded_file($_FILES['file']['tmp_name'],$destination_path) or die($_FILES['file']['error']);
			#the above function is inbuilt and it will besically move the copy file (tmp) to the destination folder .
			#after upload is done 
			#save the information 
			
			$query_string="INSERT INTO vehicle VALUES('0','$name','$type','$regnum','$seatcap','$fareperkm','$driver','$destination_path')";
	$exec=mysqli_query($connect,$query_string) or die(mysqli_error($connect));
	
	if($exec==1){
		?><script> alert('Details Updated successfully');window.location.href="vehicle.php";</script><?php	
		}
			  
			
		}else{
			#file type incorrect
			echo "<h3 style='color:red'>File type should be a image{jgp/png/gif}</h3>";
		}
	}
	
		
		
		
			
			
			
		
		}
	
			
	
	$query_view="SELECT * FROM vehicle";
	$exec=mysqli_query($connect,$query_view) or die(mysqli_error($connect));
	
	if(mysqli_num_rows($exec)>0){
		 echo "No of rows found =".mysqli_num_rows($exec);
		 ?>
         <html>
         <head>
         
         <style>
         #customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}</style>
         </head>
         <table id="customers">
         <thead>
         	<tr>
               <th>Name</th>
               <th>Vehicle Type</th>
               <th>Registration nummber</th>
               <th>Seat capacity</th>
               <th>Fare perKM</th>
               <th>Driver</th>
               <th>Picture</th>
               <th>Delete</th>
               
               
             </tr>
            </thead>
            <tbody>
    
            <?php while($each_status=mysqli_fetch_array($exec)){?>
            
            	<tr>
                	<td><?php echo $each_status['name']?></td>
                    <td><?php echo $each_status['type']?></td>
                    <td><?php echo $each_status['regnum']?></td>
                    <td><?php echo $each_status['seatcap']?></td>
                    <td><?php echo $each_status['fareperkm']?></td>
                    <td><?php echo $each_status['driver']?></td>
                   
                    
                     <td><a href="<?php echo $each_status['filepath']?>" target="_blank"><img src="<?php echo $each_status['filepath']?>" width="100" height="100"></a></td>  
                    
                    <td><a href="vehicledelete.php?v_id=<?php echo $each_status['v_id']?>&delete=1&myname=alam"
                    onclick="return confirm('Are you sure you wish to delete MR/Ms.<?php echo $each_status['name']?>')">
                    <img src="Delete.png"></a></td>
                     
                    <?php } ?>
                    </tbody>
                    </table>
                    </body>
					</html>
					<?php
					
	
          }else{
		 echo "No status found";
	 }
	                    

		

?>
</body>
</html>