 <?php include('connection2.php');?>
 <?php
  $query_view="SELECT * FROM admin";
	$exec=mysqli_query($connect,$query_view) or die(mysqli_error($connect));
	
	if(mysqli_num_rows($exec)>0){
		 echo "No of rows found =".mysqli_num_rows($exec);
		 ?>
         <html>
         <head>
         <style>
         #customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}</style>
         </head>
         <div align="center"><table id="customers">
         <thead>
         	<tr>
              
                <th>Email</th>
                <th>Password</th>
                <th>Delete</th>
               <th>Edit</th>
               <th>Change Password</th>
    
            <?php while($each_status=mysqli_fetch_array($exec)){?>
            
            	<tr>
                	
                    <td><?php echo $each_status['email']?></td>
                    <td><?php echo $each_status['password']?></td>
                    
                    <td><a href="delete2.php?a_id=<?php echo $each_status['a_id']?>&delete=1&myname=alam"
                    onclick="return confirm('Are you sure you wish to delete MR/Ms.<?php echo $each_status['email']?>')">
                    <img src="delete.png"></a></td>
                     <td><a href="update2.php?a_id=<?php echo $each_status['a_id']?>"
                    onclick="return confirm('Are you sure you wish to edit MR/Ms.<?php echo $each_status['email']?>')">
                    <img src="edit.png"></a></td>
                     <td><a href="changepassword.php?a_id=<?php echo $each_status['a_id']?>"
                    onclick="return confirm('Are you sure you wish to change password MR/Ms.<?php echo $each_status['email']?>')">
                    <img src="unlock.png"</a></td>
                     
                    </tr>
                    <?php } ?>
                    </tbody>
                    </div>
                    </table>
                    <a href="dashboard.php"><img src="back.png"></a>
					<body>
                    </html>
					<?php
					
	
	}else{
		 echo "No status found";
	 }
	                    

		

 
?>
