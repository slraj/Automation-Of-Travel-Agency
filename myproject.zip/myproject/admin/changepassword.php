<?php include('connection2.php');
if(!empty($_GET['a_id'])){
	$a_id = $_GET['a_id'];
$validity = mysqli_query($connect,"SELECT * FROM admin WHERE a_id = '$a_id'");
if(mysqli_num_rows($validity)==0){
	die("oops!something went wrong");
}
$row_id=mysqli_fetch_array($validity);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ChangePassword</title>
</head>
<body>
<form method="post">
<input type="hidden" name="id" value="<?php echo $row_id['a_id']?>">
<table>
<tr>
<td>old_password</td>
<td><textarea name="oldpassword" placeholder="Enter your old 6 characters password"></textarea></td>
</tr>
<tr>
<td>new_password</td>
<td><textarea name="newpassword" placeholder="Enter your new 6 characters password"></textarea></td>
</tr>
<tr>
<td>confirm_password</td>
<td><textarea name="confirmpassword" placeholder="Re-Enter your new 6 characters password"></textarea></td>
</tr>
<tr>
<td><input type="submit" name="go" value="go"></td>
</tr>
</table>
</form>
<?php
if(isset($_POST['go'])){
	$oldpassword=$_POST['oldpassword'];
	$newpassword=$_POST['newpassword'];
	$confirmpassword=$_POST['confirmpassword'];
	$a_id = $_POST['a_id'];
	$check = mysqli_query ($connect, "SELECT password FROM admin WHERE password='$oldpassword' AND a_id = '$a_id'");
	if(mysqli_num_rows($check)==1){
		if($newpassword==$confirmpassword){
			$query = mysqli_query($connect,"UPDATE admin SET password = '$confirmpassword' WHERE a_id = '$a_id'") or die(mysqli_error($connect));
			if($query==1){?><script> alert('Password changed successfully');window.location.href='dashboard.php';</script><?php
			}
			}else{
			?><script> alert('New Password and Confirm Password do not match');window.location.href='dashboard.php';</script><?php
		}
	}else{
		?><script> alert('Old Password does not match');window.location.href='dashboard.php';</script><?php
	}
}
?>
<?php  }?>
</body>
</html>