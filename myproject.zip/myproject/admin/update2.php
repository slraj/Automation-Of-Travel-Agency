<?php include('connection2.php');
if(!empty($_GET['a_id'])){
	$a_id=$_GET['a_id'];
$getPrevData=mysqli_query($connect,"SELECT * FROM admin WHERE a_id='$a_id'");
if(mysqli_num_rows($getPrevData)==1){
	$row=mysqli_fetch_array($getPrevData);
}
	?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit your information</title>
<style>
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 60%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>

<body >
<h1 align="center" style="color:gray">Update</h1>

<form method="post">
<input type="hidden" name="a_id" value="<?php echo $row['a_id']?>">

<table id="customers" align="center">
     <tr>
        <th>Email</th>
       </tr>
       <tr>
       <td><input type="text" name="email" placeholder="Enter your email" value="<?php echo $row['email']?>"></td>
     </tr>
     <tr>
       
   
     
     	<td><input type="submit" name="signup" value="Update"></td></tr>
        <tr><td><input type="reset" name="reset" ></td>
        </tr>
</table>

</form>
<?php
# edit code here

if(isset($_POST['signup'])){
	$a_id=$_POST['a_id'];
	$email=$_POST['email'];
	
	#update 
	$query=mysqli_query($connect,"UPDATE admin SET  eamil='$email' ") or die(mysqli_error($connect));
	if($query==1){
		 ?><script> alert('Update success');
		 	window.location.href='viewadmin.php';</script><?php
	}
}
	?>

</body>
</html>
<?php }?>