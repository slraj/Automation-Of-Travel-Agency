<?php include ('connection2.php');
 if (!empty($_GET['r_id'])){
	 
	 $r_id=$_GET['r_id'];
	 $delete_query_string="DELETE FROM route WHERE r_id='$r_id'";
	 $exec=mysqli_query($connect,$delete_query_string) or die(mysqli_error($connect));
	 if ($exec==1){
		 	?><script> alert('Delete Sucess');window.location.href="route.php";</script><?php
			
			//header('location:Untitled-1.php?delete=success');
	 }
	 
 }
	 ?>