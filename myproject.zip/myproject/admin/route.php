<?php include('connection2.php');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style>
</head>

<body>
<div>
<h1 align="center" style="color:#4CAF50">Route Details</h1>
  <form method="post">
    <label for="source"> Source</label>
    <input type="text" id="fname" name="source" >

    <label for="destination">Destination</label>
    <input type="text" id="lname" name="destination" >
    
    <label for="distance">Distance</label>
    <input type="text" id="fname" name="distance" >
    <input type="submit" value="Submit" name="submit">
    <a href="dashboard.php"><img src="back.png"></a>
    
    
  </form>
</div>

<?php
if(isset($_POST['submit'])){
	
	$source=$_POST['source'];
	$destination=$_POST['destination'];
	$distance=$_POST['distance'];
	// Inserting data
	$query_string = "INSERT INTO route VALUES('0','$source','$destination','$distance')";
	// executing command
	$exec = mysqli_query($connect,$query_string) or die(mysqli_error($connect));
	if($exec == 1){
		echo "<h1 style='color:green'>Route has registered successfully</h1>";
	}
}

$query_view="SELECT * FROM route";
	$exec=mysqli_query($connect,$query_view) or die(mysqli_error($connect));
	
	if(mysqli_num_rows($exec)>0){
		 echo "No of rows found =".mysqli_num_rows($exec);
		 ?>
         <hmtl>
         <head>
         <style>
         #customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}</style>
         </head>
         <body>
         <div align="center"><table id="customers">
         <thead>
         	<tr>
               <th>Source</th>
               <th>Destination</th>
               <th>Distance</th>
                            
               <th>Delete</th>
              
    
            <?php while($each_status=mysqli_fetch_array($exec)){?>
            
            	<tr>
                	<td><?php echo $each_status['source']?></td>
                    <td><?php echo $each_status['destination']?></td>
                    <td><?php echo $each_status['distance']?></td>
                  
                    <td><a href="deleteroute.php?r_id=<?php echo $each_status['r_id']?>&delete=1&myname=alam"
                    onclick="return confirm('Are you sure you wish to delete MR/Ms.<?php echo $each_status['source']?>')">
                    <img src="delete.png"></a></td>
                    
                     
                    </tr>
                    <?php } ?>
                    </tbody>
                    </div>
                    </table>
                    <body>
                    <html>
					<?php
					
	
	}else{
		 echo "No status found";
	 }
	                    




?>



</body>
</html>