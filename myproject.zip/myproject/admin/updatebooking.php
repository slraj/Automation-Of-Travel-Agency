 <?php include('connection2.php');?>
 <?php
  $query_view="SELECT b.*,c.*,d.*,r.*,v.*, d.name AS DRIVERNAME FROM booking b JOIN crs c JOIN driver d JOIN route r JOIN vehicle v WHERE c.u_id = b.u_id AND v.v_id = b.v_id AND r.source = b.source AND r.destination = b.destination AND d.d_id = b.d_id";
	$exec=mysqli_query($connect,$query_view) or die(mysqli_error($connect));
	
	if(mysqli_num_rows($exec)>0){
		 echo "No of rows found =".mysqli_num_rows($exec);
		 ?>
         <hmtl>
         <head>
         <style>
         #customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}</style>
         </head>
         <body>
         <div align="center"><table id="customers">
         <thead>
         	<tr>
               <th>User</th>
               <th>Vehicle</th>
               <th>Driver</th>
               <th>Total payment</th>
               <th>Source</th>
                <th>Destination</th>
                <th>Delete</th>
    
            <?php while($each_status=mysqli_fetch_array($exec)){?>
            
            	<tr>
                	<td><?php echo $each_status['u_id']?></td>
                    <td><?php echo $each_status['v_id']?></td>
                    <td><?php echo $each_status['d_id']?></td>
                    <td><?php echo $each_status['totalpayment']?></td>
                    <td><?php echo $each_status['source']?></td>
                    <td><?php echo $each_status['destination']?></td>
                    
                    <td><a href="bookingdelete.php?b_id=<?php echo $each_status['b_id']?>&delete=1&myname=alam"
                    onclick="return confirm('Are you sure you wish to delete MR/Ms.<?php echo $each_status['u_id']?>')">
                    <img src="delete.png"></a></td>
                     
                    </tr>
                    <?php } ?>
                   
                    
                    </tbody>
                    </div>
                     </table>
                    <a  href="dashboard.php"><img src="back.png"></a>
                   
                    
                   
					<?php
					
	
	}else{
		 echo "No status found";
	 }
	                    

		

 
?>
</body>
</html>
