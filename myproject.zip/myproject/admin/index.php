<?php include('connection2.php');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Login</title>

</head>

<body>
<h1 align="center" style="color:green" ><img src="banner.jpg" align="center" width="120" height="100">Admin Login</h1>
<hr></hr>
<form method="post">
<table align="center" cellpadding="20" cellspacing="0" style="border:2px solid green;background-color:tomato;">

	<tr>
    <td>Email</td>
    <td><input type="email" name="email" placeholder="Enter your email"></td>
    </tr>
    <tr>
    <td>Password</td>
    <td><input type="password" name="password" placeholder="Enter your password"></td>
    </tr>
    <tr>
    <td></td><td align="left"><input type="submit" name="login" value="Login"></td>
    </tr>
  </table>
    
</form>
<?php
if(isset($_POST['login'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	
		#check if email and password exists in db->
$checkStr="SELECT * FROM admin WHERE email='$email' AND password='$password'";
$checkLinkExec=mysqli_query($connect,$checkStr) or die(mysqli_error($connect));
 #verify if any row matches with the above details(email/password)
if(mysqli_num_rows($checkLinkExec)==1){
	#valid user
	$userData=mysqli_fetch_array($checkLinkExec);
	$_SESSION['user']=NULL;
	
	#save user details under session var
	$_SESSION['user']=$userData;
	# redirect the user to home page
	header('location:dashboard.php');
}else{
	echo "<h3 style='color:red'>Invalid User.Check your email and password.</h3>";
}
}
?>


?>

</body>
</html>