 <?php include('connection2.php');?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Driver</title>
 <style>
input[type=text], select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=go]:hover {
    background-color: #45a049;
}

div {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
</style></head>

<body>
<form method="post">
<table id="customers">
<tr>

<td><input type="hidden" name="d_id" placeholder="Enter driver Id number"></td>
</tr>
<tr>
<td>name</td>
<td><textarea name="name" placeholder="Enter driver's full name"></textarea></td>
</tr>
<tr>
<td>street</td>
<td><textarea name="street" placeholder="Enter driver's street"></textarea></td>
</tr>
<tr>
<td>location</td>
<td><textarea name="location" placeholder="Enter driver's location"></textarea></td>
</tr>
<tr>
<td>city</td>
<td><textarea name="city" placeholder="Enter driver's city"></textarea></td>
</tr>
<tr>
<td>state</td>
<td><textarea name="state" placeholder="Enter driver's state"></textarea></td>
</tr>
<tr>
<td>pincode</td>
<td><textarea name="pincode" placeholder="Enter driver's pincode"></textarea></td>
</tr>
<tr>
<td>phone</td>
<td><textarea name="mobnumber" placeholder="Enter driver's mobnumber"></textarea></td>
</tr>
<tr>
<td>license number</td>
<td><textarea name="licenseno" placeholder="Enter driver's license number"></textarea></td>
</tr>
<tr>
<td><input type="submit" name="go" value="submit"></td>
</tr>
<tr>
<td align="center"><a href="dashboard.php"><img src="back.png"></a></td></tr>
</table>

</form>
<?php
if(isset($_POST['go'])){
	$d_id=$_POST['d_id'];
	$name=$_POST['name'];
	$street=$_POST['street'];
	$location=$_POST['location'];
	$city=$_POST['city'];
	$state=$_POST['state'];
	$pincode=$_POST['pincode'];
	$mobnumber=$_POST['mobnumber'];
	$licenseno=$_POST['licenseno'];
	// Inserting data
	$query_string = "INSERT INTO driver VALUES('0','$name','$street','$location','$city','$state','$pincode','$mobnumber','$licenseno','0')";
	// executing command
	$exec = mysqli_query($connect,$query_string) or die(mysqli_error($connect));
	if($exec == 1){
		echo "<h1 style='color:green'>Driver name has registered successfully</h1>";
	}
}


 
  $query_view="SELECT * FROM driver";
	$exec=mysqli_query($connect,$query_view) or die(mysqli_error($connect));
	
	if(mysqli_num_rows($exec)>0){
		 echo "No of rows found =".mysqli_num_rows($exec);
		 ?>
         <hmtl>
         <head>
           <style>
         #customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}</style>
         </head>
         <body>
         <div align="center"><table id="customers">
         <thead>
         	<tr>
               <th> Name</th>
               <th>Street</th>
               <th>Location</th>
               <th>City</th>
               <th>State</th>
                <th>Pincode</th>
                 <th>Phone</th>
                  <th>License Number</th>
               <th>Delete</th>
               
    
            <?php while($each_status=mysqli_fetch_array($exec)){?>
            
            	<tr>
                	<td><?php echo $each_status['name']?></td>
                    <td><?php echo $each_status['street']?></td>
                    <td><?php echo $each_status['location']?></td>
                    <td><?php echo $each_status['city']?></td>
                    <td><?php echo $each_status['state']?></td>
                    <td><?php echo $each_status['pincode']?></td>
                    <td><?php echo $each_status['mobnumber']?></td>
                    <td><?php echo $each_status['licenseno']?></td>
                    
                    <td><a href="deletedriver.php?d_id=<?php echo $each_status['d_id']?>&delete=1&myname=alam"
                    onclick="return confirm('Are you sure you wish to delete MR/Ms.<?php echo $each_status['name']?>')">
                    <img src="delete.png"></a></td>
                    
                    </tr>
                    <?php } ?>
                    </tbody>
                    </div>
                    </table>
                    <body>
                    <html>
					<?php
					
	
	}else{
		 echo "No status found";
	 }
	                    

		

 
?>
</body>
</html>