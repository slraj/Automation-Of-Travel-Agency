<?php include('connection2.php');
if(!empty($_GET['u_id'])){
	$u_id=$_GET['u_id'];
$getPrevData=mysqli_query($connect,"SELECT * FROM crs WHERE u_id='$u_id'");
if(mysqli_num_rows($getPrevData)==1){
	$row=mysqli_fetch_array($getPrevData);
}
	?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Edit your information</title>
</head>

<body style="background-image:url(banner2.JPG)">
<h1 align="center" style="color:gray">Update</h1>
<form method="post">
<input type="hidden" name="u_id" value="<?php echo $row['u_id']?>">

<table align=
"center" style="background-color:gray;" cellpadding="15" border="4" style="border-radius:10px;">
	<tr>
    	<td>First Name</td>
        <td><input type="text" name="f_name" placeholder="Enter your name" value="<?php echo $row['f_name']?>">

        </td>
    </tr>
    <tr>
        <td>Last_Name</td>
        <td><input type="text" name="l_name" placeholder="Enter your email" value="<?php echo $row['l_name']?>"></td>
    </tr>
    <tr>
        <td>Gender</td>
        <td><input type="text" name="gender" placeholder="Enter your password" value="<?php echo $row['gender']?>"></td>
    </tr>
    </tr>
        <td>Phone Number</td>
        <td><input type="number" name="phone" placeholder="Enter your password" value="<?php echo $row['phone']?>"></td>
     </tr>
    <tr>
        <td>Address</td>
        <td><textarea name="address" placeholder="Enter the address"></textarea></td>
    </tr>
     <tr>
        <td>Email</td>
       <td><input type="text" name="email" placeholder="Enter your password" value="<?php echo $row['email']?>"></td>
     </tr>
   
     
     	<td><input type="submit" name="signup" value="Update"></td>
        <td><input type="reset" name="reset" ></td>
        </tr>
</table>

</form>
<?php
# edit code here

if(isset($_POST['signup'])){
	$u_id=$_POST['u_id'];
	$f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$gender=$_POST['gender'];
	$phone=$_POST['phone'];
	$address=$_POST['address'];
	$email=$_POST['email'];
	
	#update 
	$query=mysqli_query($connect,"UPDATE crs SET f_name='$f_name' ,l_name='$l_name' ,gender='$gender' ,phone='$phone' , address='$address' ") or die(mysqli_error($connect));
	if($query==1){
		 ?><script> alert('Update success');
		 	window.location.href='delete1.php';</script><?php
	}
}
	?>

</body>
</html>
<?php }?>