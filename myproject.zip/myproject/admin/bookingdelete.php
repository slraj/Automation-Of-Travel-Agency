<?php include ('connection2.php');
 if (!empty($_GET['b_id'])){
	 
	 $b_id=$_GET['b_id'];
	 $delete_query_string="DELETE FROM booking WHERE b_id='$b_id'";
	 $exec=mysqli_query($connect,$delete_query_string) or die(mysqli_error($connect));
	 if ($exec==1){
		 	?><script> alert('Delete Sucess');window.location.href="updatebooking.php";</script><?php
			
			//header('location:Untitled-1.php?delete=success');
	 }
	 
 }
	 ?>