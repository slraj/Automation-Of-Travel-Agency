<?php include ('connection2.php');
 if (!empty($_GET['d_id'])){
	 
	 $d_id=$_GET['d_id'];
	 $delete_query_string="DELETE FROM driver WHERE d_id='$d_id'";
	 $exec=mysqli_query($connect,$delete_query_string) or die(mysqli_error($connect));
	 if ($exec==1){
		 	?><script> alert('Delete Sucess');window.location.href="driver.php";</script><?php
			
			//header('location:Untitled-1.php?delete=success');
	 }
	 
 }
	 ?>