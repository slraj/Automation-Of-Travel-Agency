<?php include ('connection2.php');
 if (!empty($_GET['u_id'])){
	 
	 $u_id=$_GET['u_id'];
	 $delete_query_string="DELETE FROM crs WHERE u_id='$u_id'";
	 $exec=mysqli_query($connect,$delete_query_string) or die(mysqli_error($connect));
	 if ($exec==1){
		 	?><script> alert('Delete Sucess');window.location.href="delete.php";</script><?php
			
			//header('location:Untitled-1.php?delete=success');
	 }
	 
 }
	 ?>