<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php
$getLastBooking = mysqli_query($connect,"SELECT b.*,c.*,d.*,r.*,v.*, d.name AS DRIVERNAME FROM booking b JOIN crs c JOIN driver d JOIN route r JOIN vehicle v WHERE c.u_id = b.u_id AND v.v_id = b.v_id AND r.source = b.source AND r.destination = b.destination AND d.d_id = b.d_id AND c.u_id = '".$_SESSION['user']['u_id']) or die(mysqli_error($connect));


?>
</body>
</html>