<!DOCTYPE HTML>
<html>
	<head>
		<title>Contact Us</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header" class="alt">
				<div class="logo"><a href="index.php">Car Rental Service <span>by C.R.S.</span></a></div>
				<a href="#menu"><span>Menu</span></a>
			</header>

		
		<!-- Main -->
			<div id="main" class="container">
			  <h3><p align="center">!!!We are happy to help you!!!</p></h3><hr><hr>
					<div class="row">
						<div class="6u 12u$(small)">
							<h3>Mail us on</h3>
							<p>saurabhlewisraj@gmail.com / anujdeepktr@gmail.com</p><br><p>alamgiralam5991@gmail.com / aritra.datta97@gmail.com</p>
						</div>
						<div class="6u$ 12u$(small)">
							<h3>Contact us on</h3>
							<p>(+91) 95214 06250 / (+91) 70040 11477</p><br><p>(+91) 80167 93439 / (+91) 98042 62549</p>
						</div>
						<!-- Break -->
						<div class="4u 12u$(medium)">
							<h4><p><u>Follow Us on</p></h4>
										<ul class="icons">
											<li><a href="https://twitter.com/C_R_service" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
											<li><a href="https://www.facebook.com/CRS-216075018964468/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
											<li><a href="https://www.instagram.com/c.r.s.4542/" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
                                            </ul>
						</div>
                    </div>
             </div>
		<!-- Footer -->
			<footer id="footer">
				<div class="inner">

					<h2>Leave a message</h2>

					<form action="#" method="post">

						<div class="field half first">
							<label for="name">Name</label>
							<input name="name" id="name" type="text" placeholder="Name">
						</div>
						<div class="field half">
							<label for="email">Email</label>
							<input name="email" id="email" type="email" placeholder="Email">
						</div>
						<div class="field">
							<label for="message">Message</label>
							<textarea name="message" id="message" rows="6" placeholder="Message"></textarea>
						</div>
						<ul class="actions">
							<li><input value="Send Message" class="button alt" type="submit"></li>
						</ul>
					</form>

					<div class="copyright">
						&copy; All Rights Reserved. Design: Car Rental Service.
					</div>

				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
            <!-- Nav -->
			<?php include ("navbar.php")?>


	</body>
</html>