<?php include ('connection2.php');
if(isset($_POST['submit'])){
	$vid = $_POST['v_id'];
	$source = $_POST['source'];
	$destination = $_POST['destination'];
	$fare = $_POST['amount'];
	$uid = $_SESSION['user']['u_id'];
	$qry = mysqli_query($connect,"SELECT * FROM vehicle WHERE v_id = '$vid'");
	
	$vehicleInfo = mysqli_fetch_array($qry);
	$ppk = $vehicleInfo['fareperkm'];
	$did = $vehicleInfo['driver'];
	
	$query_string="INSERT INTO booking VALUES('0','$uid','$vid','$did','$fare','$source','$destination')";
	$exec=mysqli_query($connect,$query_string) or die(mysqli_error($connect));
	
	




?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Booking Confirmed</title>
</head>
<?php 
$getLastBooking = mysqli_query($connect,"SELECT b.*,c.*,d.*,r.*,v.*, d.name AS DRIVERNAME FROM booking b JOIN crs c JOIN driver d JOIN route r JOIN vehicle v WHERE c.u_id = b.u_id AND v.v_id = b.v_id AND r.source = b.source AND r.destination = b.destination AND d.d_id = b.d_id AND c.u_id = '".$_SESSION['user']['u_id']."' ORDER BY c.u_id DESC LIMIT 1") or die(mysqli_error($connect));

if(mysqli_num_rows($getLastBooking)==0){
	die("Something went wrong in booking join");
}
$row = mysqli_fetch_array($getLastBooking);
?>
<body bgcolor="#CCFF99">
<h2><p align="center"><font face="monotype corsiva" color="#FF0000">Your Cab is booked.Driver will call you in 15 mins.!!!</font></p></h2><hr>
<h1><p align="center">INVOICE COPY</p></h1>
<table cellpadding="5" border="1" cellspacing="0" align="center">
<thead align="center">
<tr align="center">
<th>User</th>
<th>Car</th>
<th>Driver</th>
<th>Source</th>
<th>Destination</th>
<th>Total fare</th>
</tr>
</thead>
<tbody>
<tr>
<td><?php echo $row['f_name']?></td>
<td><?php echo $row['name']?></td>
<td><?php echo $row['DRIVERNAME']?></td>
<td><?php echo $row['source']?></td>
<td><?php echo $row['destination']?></td>
<td><?php echo $row['totalpayment']?></td>
</tr>
</tbody>
</tr>
</table>
<h1><p align="center" style="text-shadow:#999">!!!Thanks for travelling with us!!!</p></h1>
<p align="center">Back to Home<a href="home.php"><img src="home.png"></a></p><?php 
}else{
	header('location:booking.php?err=something went wrong');
}
?>
</body>
</html>