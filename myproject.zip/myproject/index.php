<!DOCTYPE HTML>
<html>
	<head>
		<title>C.R.S.|Car Rental Service</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<div class="logo"><a href="index.php">Car Rental Service <span>by C.R.S.</span></a></div>
                 <a href="#menu"><span>Menu</span></a>
			</header>

		<!-- Nav -->
			<?php include ("navbar.php")?>

		<!-- Banner -->
		<!--
			Note: To show a background image, set the "data-bg" attribute below
			to the full filename of your image. This is used in each section to set
			the background image.
		-->
			<section id="banner" class="bg-img" data-bg="banner.jpg">
				<div class="inner">
					<header>
						<h1>Welcome to Car Rental Service</h1>
					</header>
				</div>
				<a href="#one" class="more">Learn More</a>
			</section>

		<!-- One -->
			<section id="one" class="wrapper post bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>CAR RENTAL SERVICE</h2>
							
						</header>
						<div class="content">
							<p>C.R.S., City's most popular car rental site for transportation, integrates city transportation for customers and driver partners onto a web technology platform.</p>
                            <p align="center">For more details click on Learn More.</p>
						</div>
						<footer>
							<a href="about.php" class="button alt">Learn More</a>
						</footer>
					</article>
				</div>
				<a href="#two" class="more">Learn More</a>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper post bg-img" data-bg="banner5.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>LESS FARE, MORE COMFORT</h2>
							
						</header>
						<div class="content">
							<p>Here we have varities of cars so everyone can afford and take a secure and luxurious ride.</p>
                            <p align="center">For more details of Cars click on Learn More.</p>
						</div>
						<footer>
							<a href="about.php" class="button alt">Learn More</a>
						</footer>
					</article>
				</div>
				<a href="#three" class="more">Learn More</a>
			</section>

		<!-- Three -->
			<section id="three" class="wrapper post bg-img" data-bg="banner4.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Servicing</h2>
							
						</header>
						<div class="content">
							<p>Services of C.R.S. are provided across the whole city.<br>Whereever you want we deliver you on time at the lowest cost.</p>
                            <p align="center">For more details click on Learn More.</p>
						</div>
						<footer>
							<a href="about.php" class="button alt">Learn More</a>
						</footer>
					</article>
				</div>
				<a href="#four" class="more">Learn More</a>
			</section>

		<!-- Four -->
			<section id="four" class="wrapper post bg-img" data-bg="banner3.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h2>Why C.R.S.</h2>
						</header>
                        <ul class="icons">
						<li><a class="icon round fa-car fa-3x"><span class="label">comfort_car</span></a></li>
						<li><a class="icon round fa-check-circle fa-3x"><span class="label">certified</span></a></li>
						<li><a class="icon round fa-clock-o fa-3x"><span class="label">ontime_service</span></a></li>
                        <li><a class="fa fa-drivers-license" style="font-size:48px"></a></li>
                        <li><a class="icon round fa-globe fa-3x"><span class="label">National_Services</span></a></li>
                        <li><a class="icon round fa-wifi fa-3x"><span class="label">Wifi_Supported_Cars</span></a></li>
						</ul>
						<div class="content">
							<p>Benefits of C.R.S. : Comfortable Cars, Certified Provider, On time Service, Experienced and licenced drivers, National Service, Wifi supported cars and a lot more</p>
						</div>
						<footer>
							<a href="about.php" class="button alt">Learn More</a>
						</footer>
					</article>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">

					<h2>Leave us a message!!!</h2>

					<form action="#" method="post">

						<div class="field half first">
							<label for="name">Name</label>
							<input name="name" id="name" type="text" placeholder="Name">
						</div>
						<div class="field half">
							<label for="email">Email</label>
							<input name="email" id="email" type="email" placeholder="Email">
						</div>
						<div class="field">
							<label for="message">Message</label>
							<textarea name="message" id="message" rows="6" placeholder="Message"></textarea>
						</div>
						<ul class="actions">
							<li><input value="Send Message" class="button alt" type="submit"></li>
						</ul>
					</form>

					<ul class="icons">
						<li><a href="https://twitter.com/C_R_service" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
											<li><a href="https://www.facebook.com/CRS-216075018964468/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
											<li><a href="https://www.instagram.com/c.r.s.4542/" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					</ul>

					<div class="copyright">
						&copy; All Rights Reserved. Design: Car Rental Service.
					</div>

				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>