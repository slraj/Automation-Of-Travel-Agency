<!DOCTYPE HTML>
<html>
	<head>
		<title>About-Car Rental Service</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body class="subpage">

		<!-- Header -->
			<header id="header" class="alt">
				<div class="logo"><a href="index.php">Car Rental Service <span>by C.R.S.</span></a></div>
				<a href="#menu"><span>Menu</span></a>
			</header>

		
		<!-- Content -->
		<!--
			Note: To show a background image, set the "data-bg" attribute below
			to the full filename of your image. This is used in each section to set
			the background image.
		-->
			<section id="post" class="wrapper bg-img" data-bg="banner2.jpg">
				<div class="inner">
					<article class="box">
						<header>
							<h1><u>C.R.S.|Car Rental Service</u></h1>
							<p>05.01.2018</p>
						</header>
						<div class="content">
                            <h2><p align="center">Company Profile</h2><br>
Car Rental Service is a One Stop Travel Shop providing services to Individual tourist as well as corporate houses. Car Rental Service specializes in domestic, inbound holidays, travels and provides customized itineraries across all destinations in the city.<br>
Our commitment to the customers, to offer international standard service & ensure a high level of quality, convenience, safety and custom.Until now, only in the view of the uncountable tourists all around City, it has been considered to be one of the best upgrowing travel service providers in City. It is made possible only for the experienced, efficient and dedicated professional team in our organization who has worked day in and day out to make your journey comfortable.<br>
The team member sacrificed their comfort, holidays, sleep, food and entertainment for the sake of the travelers in their journey. As a result, our organization has earned the trust of the people all around the city to be one of the best travel service providers in the City.
</p><hr>
							<h2><p align="center">Services of Car Rental Service</p></h2><br>
                            <p>More choices. Best Rates.</p>
                            <h3><p><u>Our web site will allow you to:</u></p></h3>
							<p><blockquote>1.View our Fleet of Vehicles and Rates.</blockquote><br>
                            <blockquote>2.Make a car reservation by your own effort.</blockquote><br>
                            <blockquote>3.CUSTOMIZED TOURS<br>
							Visit popular attractions or go off the beaten track. Set your own itinerary and pace and we will take you there.</blockquote><br>
                            <blockquote>4.VEHICLE AND DRIVER SERVICE<br>
                            This service includes regular vehicle and driver service as well as VIP Chauffeur services. Available for short or extended periods.</blockquote><br>
                            <blockquote>5.PICK UP AND DELIVERY<br>
                            Staying at a hotel or villa? We will deliver and pick up.</blockquote></p>
                            <hr>
							<h2><p align="center">Why Car Rental Service</p></h2><br>
							<p align="center">Because you believe on us so we fullfill your desire at your doorstep.</p>
						</div>
					</article>
				</div>
                <h3><p align="center"><u><font color="#FF0000">"C.R.S. WILL TAKE BETTER CARE OF YOU"</font></u></p></h3>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">

					<h2>Leave us a message</h2>

					<form action="#" method="post">

						<div class="field half first">
							<label for="name">Name</label>
							<input name="name" id="name" type="text" placeholder="Name">
						</div>
						<div class="field half">
							<label for="email">Email</label>
							<input name="email" id="email" type="email" placeholder="Email">
						</div>
						<div class="field">
							<label for="message">Message</label>
							<textarea name="message" id="message" rows="6" placeholder="Message"></textarea>
						</div>
						<ul class="actions">
							<li><input value="Send Message" class="button alt" type="submit"></li>
						</ul>
					</form>

					<ul class="icons">
						<li><a href="https://twitter.com/C_R_service" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
											<li><a href="https://www.facebook.com/CRS-216075018964468/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
											<li><a href="https://www.instagram.com/c.r.s.4542/" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
					</ul>

					<div class="copyright">
						&copy; All Rights Reserved. Design: Car Rental Service.
					</div>

				</div>
			</footer>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
            <!-- Nav -->
			<?php include ("navbar.php")?>


	</body>
</html>