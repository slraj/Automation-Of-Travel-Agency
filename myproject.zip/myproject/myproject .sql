-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 10, 2018 at 08:41 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `myproject`
--
CREATE DATABASE IF NOT EXISTS `myproject` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `myproject`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `email`, `password`) VALUES
(1, 'alamgiralam@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE IF NOT EXISTS `booking` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `v_id` int(11) NOT NULL,
  `d_id` int(11) NOT NULL,
  `totalpayment` text NOT NULL,
  `source` text NOT NULL,
  `destination` text NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`b_id`, `u_id`, `v_id`, `d_id`, `totalpayment`, `source`, `destination`) VALUES
(1, 3, 5, 2, '105', 'Howrah', 'Sealdah'),
(2, 3, 6, 3, '158', 'Howrah', 'Sealdah'),
(3, 3, 5, 2, '105', 'Howrah', 'Sealdah'),
(4, 3, 5, 2, '105', 'Howrah', 'Sealdah'),
(5, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(6, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(7, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(8, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(9, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(10, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(11, 3, 5, 2, '210', 'Sealdah', 'Howrah'),
(13, 3, 5, 2, '105', 'Howrah', 'Sealdah');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`co_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `crs`
--

CREATE TABLE IF NOT EXISTS `crs` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` text NOT NULL,
  `l_name` text NOT NULL,
  `gender` text NOT NULL,
  `phone` text NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `crs`
--

INSERT INTO `crs` (`u_id`, `f_name`, `l_name`, `gender`, `phone`, `address`, `email`, `password`) VALUES
(3, 'alamgir', 'alam', 'Male', '8016793439', 'Kulti', 'alamgiralam5991@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE IF NOT EXISTS `driver` (
  `d_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `street` text NOT NULL,
  `location` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `pincode` text NOT NULL,
  `mobnumber` text NOT NULL,
  `licenseno` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`d_id`, `name`, `street`, `location`, `city`, `state`, `pincode`, `mobnumber`, `licenseno`, `status`) VALUES
(2, 'Saurabh Raj', 'Kolkata', 'Kolkata', 'Kolkata', 'WB', '700104', '9865320122', 'RGID456', 1),
(3, 'Ajay Sharma', 'Park Street', 'Kolkata', 'kolkata', 'WB', '700013', '7845123696', 'RGID789', 1),
(4, 'Alamgir Alam', 'Parkcircus', 'Kolkata', 'Kolkata', 'WB', '7000014', '8016793439', 'RGID007', 1),
(5, 'Aritra Datta', 'Howrah', 'Kolkata', 'Kolkata', 'WB', '700001', '7898654512', 'RGID001', 1);

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `source` text NOT NULL,
  `destination` text NOT NULL,
  `distance` text NOT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`r_id`, `source`, `destination`, `distance`) VALUES
(1, 'Howrah', 'Sealdah', '10'),
(2, 'Sealdah', 'Howrah', '20'),
(3, 'Kolkata', 'Durgapur', '100'),
(4, 'Durgapur', 'Kolkata', '150');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE IF NOT EXISTS `vehicle` (
  `v_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `regnum` text NOT NULL,
  `seatcap` text NOT NULL,
  `fareperkm` text NOT NULL,
  `driver` text NOT NULL,
  `filepath` text NOT NULL,
  PRIMARY KEY (`v_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_id`, `name`, `regnum`, `seatcap`, `fareperkm`, `driver`, `filepath`) VALUES
(5, 'Celerio', 'WB1234', '5', '10', '2', 'images/7648_celerio.jpg'),
(6, 'Bolero', 'WB5678', '8', '15', '3', 'images/5123_bolero.jpg'),
(7, 'Hyundai', 'WB0007', '6', '12', '4', 'images/4081_hyundai.jpg'),
(8, 'Gypsy', 'WB0009', '5', '11', '5', 'images/1458_gypsy.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
