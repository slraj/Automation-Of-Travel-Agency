<?php include ('connection2.php')?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Login/Register</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div class="logmod">
  <div class="logmod__wrapper">
    <span class="logmod__close">Close</span>
    <div class="logmod__container">
      <ul class="logmod__tabs">
        <li data-tabtar="lgm-2"><a href="#">Login</a></li>
        <li data-tabtar="lgm-1"><a href="#">Sign Up</a></li>
      </ul>
      <div class="logmod__tab-wrapper">
      <div class="logmod__tab lgm-1">
        
        <div class="logmod__form">
          <form accept-charset="utf-8" action="#" class="simform" method="post">
             <div class="sminputs">
              <div class="input string optional">
                <label class="string optional" for="user-fnm">First Name *</label>
                <input class="string optional" maxlength="255" id="user-nm" placeholder="First Name" type="text" name="f_name" size="50" />
              </div>
              <div class="input string optional">
                <label class="string optional" for="user-lnm">Last Name *</label>
                <input class="string optional" maxlength="255" id="user-lnm" placeholder="Last Name" type="text" name="l_name" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
              	<label class="string optional" for="user-gender">Gender *
                <select name="gender">
  					<option>Male</option>
  					<option>Female</option>
  					<option>Others</option>
				</select></label>
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-phn">Phone No *</label>
                <input class="string optional" maxlength="255" id="user-phn" placeholder="Contact Number" type="text" name="phone" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-address">Address *</label>
                <input class="string optional" maxlength="255" id="user-address" placeholder="Address" type="text" name="address" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-email">Email*</label>
                <input class="string optional" maxlength="255" id="user-email" placeholder="Email" type="email" name="email" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input string optional">
                <label class="string optional" for="user-pw">Password *</label>
                <input class="string optional" maxlength="255" id="user-pw" placeholder="Password" type="password" name="password" size="50" />
              </div>
              <div class="input string optional">
                <label class="string optional" for="user-pw-repeat">Repeat password *</label>
                <input class="string optional" maxlength="255" id="user-pw-repeat" placeholder="Repeat password" type="password" name="repeatpassword" size="50" />
              </div>
            </div>
            <div class="simform__actions">
              <a href="home.php"><input class="sumbit" name="submit" type="submit" value="Create Account" /></a>
              <span class="simform__actions-sidetext">By creating an account you agree to our <a class="special" href="t_c.html" role="link">Terms & Conditions</a></span>
            </div> 
          </form>
        </div> 
      </div>
      <div class="logmod__tab lgm-2">
        <div class="logmod__heading">
          <span class="logmod__heading-subtitle">Enter your email and password <strong>to sign in</strong></span>
        </div> 
        <div class="logmod__form">
          <form accept-charset="utf-8" action="#" class="simform" method="post">
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-name">Email*</label>
                <input class="string optional" maxlength="255" id="user-email" placeholder="Email" type="email" name="email1" size="50" />
              </div>
            </div>
            <div class="sminputs">
              <div class="input full">
                <label class="string optional" for="user-pw">Password *</label>
                <input class="string optional" maxlength="255" id="user-pw" placeholder="Password" type="password" name="password1" size="50" />
                						<span class="hide-password">Show</span>
              </div>
            </div>
            <div class="simform__actions">
              <a href="home.php"><input class="sumbit" name="login" type="submit" value="Log In" /></a>
            </div> 
          </form>
        </div> 
       </div>
      </div>
    </div>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  <script  src="js/index.js"></script>
<?php
if(isset($_POST['submit']))
{
		$f_name=$_POST['f_name'];
		$l_name=$_POST['l_name'];
		$gender=$_POST['gender'];
		$phone=$_POST['phone'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$password=$_POST['password'];
	
	$query="SELECT * FROM crs WHERE email='$email'";
	$exec=mysqli_query($connect,$query) or die(mysql_error($connect));
	if(mysqli_num_rows($exec)==1)
	{
		echo "<h3 style='color:red'>email already exists</h3>";
	}
	else
	{
			$_SESSION['user'] = $f_name;
			$query_string="INSERT INTO crs VALUES('0','$f_name','$l_name','$gender','$phone','$address','$email','$password')";
	$exec=mysqli_query($connect,$query_string) or die(mysqli_error($connect));
	
		if($exec==1)
		{
		header('location:home.php');
		}
	}
}

?>
<?php
if(isset($_POST['login'])){
	$email1=$_POST['email1'];
	$password1=$_POST['password1'];
	
		#check if email and password exists in db->
$checkStr="SELECT * FROM crs WHERE email='$email1' AND password='$password1'";
$checkLinkExec=mysqli_query($connect,$checkStr) or die(mysqli_error($connect));
 #verify if any row matches with the above details(email/password)
if(mysqli_num_rows($checkLinkExec)==1){
	#valid user
	$userData=mysqli_fetch_array($checkLinkExec);
	$_SESSION['user']=NULL;
	
	#save user details under session var
	$_SESSION['user']=$userData;
	# redirect the user to home page
	header('location:home.php');
}else{
	echo "<h3 style='color:red'>Invalid User.Check your email and password.</h3>";
}
}
?>

</body>
</html>
