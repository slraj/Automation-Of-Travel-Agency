<?php include ('connection2.php')?>
<nav id="menu">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="contactus.php">Contact Us</a></li>
                    <?php if(!isset($_SESSION['user'])){?>
                    <li><a href="backup_login.php">Login/Register</a></li>
                    <?php } else{ ?>
                    <li><a href="cp.php">Change Password</a></li>
					<li><a href="booking.php">Booking</a></li>
					<li><a href="logout.php">Log Out</li>
                    <?php }?>
                    
				</ul>
			</nav>